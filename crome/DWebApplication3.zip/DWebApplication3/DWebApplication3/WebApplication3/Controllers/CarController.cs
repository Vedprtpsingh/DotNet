﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using WebApplication3.Models;
using System.Data;

namespace WebApplication3.Controllers
{
    public class CarController : Controller
    {
        SqlConnection db;
        SqlCommand cm;
        SqlDataReader dr;

        string con =
        @"Server=pavelRDX;
        Database=Car;
        Integrated Security=True;
        TrustServerCertificate=True";

        string st = "";

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Insert(IFormCollection fc)
        {
            db = new SqlConnection(con);
            db.Open();

            st = " IF NOT EXISTS (SELECT 1 FROM dbo.Car WHERE Sid = @Sid)"+
                 "INSERT INTO dbo.Car(Sid,Sname,Course,Marks)" +
                 "values(@Sid, @Sname, @Course, @Marks)";

            cm = new SqlCommand(st,db);
            cm.Parameters.AddWithValue("@Sid", fc["Sid"].ToString());
            cm.Parameters.AddWithValue("@Sname", fc["Sname"].ToString());
            cm.Parameters.AddWithValue("@Course", fc["Course"].ToString());
            cm.Parameters.AddWithValue("@Marks", fc["Marks"].ToString());
            cm.ExecuteNonQuery();

            ViewBag.Message = "Record Inserted";
            return View("Index");
        }

        public IActionResult Show(IFormCollection fc)
        {
            db = new SqlConnection(con);
            db.Open();

            st = "select * from Car where Sid=@Sid";

            cm = new SqlCommand(st, db);
            cm.Parameters.AddWithValue("@Sid", fc["Sid"].ToString());
            dr = cm.ExecuteReader();

            if (dr.Read())
            {
                Car s = new Car();

                s.Sid = Convert.ToInt32(dr["Sid"]);
                s.Sname = dr["Sname"].ToString();
                s.Course = dr["Course"].ToString();
                s.Marks = Convert.ToInt32(dr["Marks"]);

                return View(s);
            }

            ViewBag.Message = "Record Not Found";
            return View("Index");
        }

        public IActionResult Modify(IFormCollection fc)
        {
            db = new SqlConnection(con);
            db.Open();

            st = "update Car set Sname=@Sname, Course=@Course, Marks=@Marks where Sid=@Sid";

            cm = new SqlCommand(st, db);
            cm.Parameters.AddWithValue("@Sid", fc["Sid"].ToString());
            cm.Parameters.AddWithValue("@Sname", fc["Sname"].ToString());
            cm.Parameters.AddWithValue("@Course", fc["Course"].ToString());
            cm.Parameters.AddWithValue("@Marks", fc["Marks"].ToString());
            cm.ExecuteNonQuery();

            ViewBag.Message = "Record Modified";

            return View("Index");
        }

        public IActionResult Delete(IFormCollection fc)
        {
            db = new SqlConnection(con);
            db.Open();

            st = "delete from Car where Sid=@Sid";

            cm = new SqlCommand(st, db);
            cm.Parameters.AddWithValue("@Sid", fc["Sid"].ToString());
            cm.ExecuteNonQuery();

            ViewBag.Message = "Record Deleted";

            return View("Index");
        }

        public IActionResult Display()
        {
            List<Car> list = new List<Car>();

            db = new SqlConnection(con);
            db.Open();

            st = "select * from Car";

            cm = new SqlCommand(st, db);
            dr = cm.ExecuteReader();

            while (dr.Read())
            {
                Car s = new Car();

                s.Sid = Convert.ToInt32(dr["Sid"]);
                s.Sname = dr["Sname"].ToString();
                s.Course = dr["Course"].ToString();
                s.Marks = Convert.ToInt32(dr["Marks"]);

                list.Add(s);
            }

            return View(list);
        }
    }
}
