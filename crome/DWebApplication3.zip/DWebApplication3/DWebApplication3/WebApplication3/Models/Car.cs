﻿namespace WebApplication3.Models
{
    public class Car
    {
        public int Sid { get; set; }
        public string Sname { get; set; }   
        public string Course { get; set; }
        public int Marks { get; set; }
    }
}
