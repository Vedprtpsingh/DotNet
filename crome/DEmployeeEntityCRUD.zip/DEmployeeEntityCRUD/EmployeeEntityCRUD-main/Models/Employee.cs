﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeEntityCRUD.Models
{
    public class Employee
    {
        [Key]
        [Required]
        public int Eno { get; set; }

        [Required(ErrorMessage = "Employee Name is required")]
        [StringLength(50)]
        public string Ename { get; set; }

        [Required(ErrorMessage = "Salary is required")]
        [Range(1000, 1000000)]
        public double Salary { get; set; }
    }
}